<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
requireLogin();
requireStaff();

$pageTitle = 'Laporan Transaksi - Perpustakaan SD N 1 Plebengan';

// --- Filter periode & status ---
$statusValid = ['dipinjam', 'dikembalikan', 'terlambat'];
$filterStatus = (isset($_GET['status']) && in_array($_GET['status'], $statusValid, true)) ? $_GET['status'] : '';
$semua = isset($_GET['semua']);

function isValidDate($d) {
    return (bool) preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $d);
}

if ($semua) {
    $dari = '';
    $sampai = '';
} else {
    $dari = isValidDate($_GET['dari'] ?? '') ? $_GET['dari'] : date('Y-m-01');
    $sampai = isValidDate($_GET['sampai'] ?? '') ? $_GET['sampai'] : date('Y-m-d');
}

$whereParts = ["1=1"];
if ($dari !== '') $whereParts[] = "t.tanggal_pinjam >= '" . mysqli_real_escape_string($conn, $dari) . "'";
if ($sampai !== '') $whereParts[] = "t.tanggal_pinjam <= '" . mysqli_real_escape_string($conn, $sampai) . "'";
if ($filterStatus !== '') $whereParts[] = "t.status = '" . mysqli_real_escape_string($conn, $filterStatus) . "'";
$whereClause = "WHERE " . implode(' AND ', $whereParts);

$transaksi = mysqli_query($conn, "SELECT t.*, b.judul, b.kode_buku, u.nama_lengkap
    FROM transaksi t
    JOIN buku b ON t.id_buku = b.id_buku
    JOIN users u ON t.id_user = u.id_user
    $whereClause ORDER BY t.tanggal_pinjam ASC, t.id_transaksi ASC");

$rows = [];
$totalDenda = 0;
$statusCount = ['dipinjam' => 0, 'dikembalikan' => 0, 'terlambat' => 0];
while ($r = mysqli_fetch_assoc($transaksi)) {
    $rows[] = $r;
    $totalDenda += (float) $r['denda'];
    if (isset($statusCount[$r['status']])) $statusCount[$r['status']]++;
}
$totalRows = count($rows);

$statusLabel = ['dipinjam' => 'Dipinjam', 'dikembalikan' => 'Dikembalikan', 'terlambat' => 'Terlambat'];
$statusBadgeColor = ['dipinjam' => 'orange', 'dikembalikan' => 'green', 'terlambat' => 'red'];

$periodeText = ($dari === '' && $sampai === '')
    ? 'Semua Periode'
    : date('d F Y', strtotime($dari)) . ' s.d. ' . date('d F Y', strtotime($sampai));
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css?v=20260827">
</head>
<body class="report-body">
<div class="report-page">

    <div class="report-toolbar no-print">
        <a href="transaksi.php" class="btn btn-secondary">&larr; Kembali ke Transaksi</a>
        <button type="button" class="btn btn-primary" onclick="window.print()">🖨️ Cetak / Simpan PDF</button>
    </div>

    <form method="GET" class="report-filter-form no-print">
        <div class="form-group">
            <label>Dari Tanggal</label>
            <input type="date" name="dari" value="<?php echo htmlspecialchars($dari); ?>">
        </div>
        <div class="form-group">
            <label>Sampai Tanggal</label>
            <input type="date" name="sampai" value="<?php echo htmlspecialchars($sampai); ?>">
        </div>
        <div class="form-group">
            <label>Status</label>
            <select name="status">
                <option value="">Semua Status</option>
                <option value="dipinjam" <?php echo $filterStatus === 'dipinjam' ? 'selected' : ''; ?>>Dipinjam</option>
                <option value="dikembalikan" <?php echo $filterStatus === 'dikembalikan' ? 'selected' : ''; ?>>Dikembalikan</option>
                <option value="terlambat" <?php echo $filterStatus === 'terlambat' ? 'selected' : ''; ?>>Terlambat</option>
            </select>
        </div>
        <div class="form-group report-filter-actions">
            <button type="submit" class="btn btn-primary">🔍 Tampilkan</button>
            <a href="?semua=1<?php echo $filterStatus ? '&status=' . urlencode($filterStatus) : ''; ?>" class="btn btn-secondary">Semua Periode</a>
        </div>
    </form>

    <!-- Kop laporan -->
    <div class="report-header">
        <h2>📚 Perpustakaan SD N 1 Plebengan</h2>
        <h3>Laporan Transaksi Peminjaman &amp; Pengembalian Buku</h3>
        <p class="report-period">Periode: <?php echo $periodeText; ?><?php echo $filterStatus ? ' &middot; Status: ' . htmlspecialchars($statusLabel[$filterStatus]) : ''; ?></p>
    </div>

    <!-- Ringkasan -->
    <div class="report-summary-grid">
        <div class="report-summary-box">
            <div class="report-summary-num"><?php echo $totalRows; ?></div>
            <div class="report-summary-label">Total Transaksi</div>
        </div>
        <div class="report-summary-box">
            <div class="report-summary-num"><?php echo $statusCount['dipinjam']; ?></div>
            <div class="report-summary-label">Dipinjam</div>
        </div>
        <div class="report-summary-box">
            <div class="report-summary-num"><?php echo $statusCount['dikembalikan']; ?></div>
            <div class="report-summary-label">Dikembalikan</div>
        </div>
        <div class="report-summary-box">
            <div class="report-summary-num"><?php echo $statusCount['terlambat']; ?></div>
            <div class="report-summary-label">Terlambat</div>
        </div>
        <div class="report-summary-box">
            <div class="report-summary-num">Rp <?php echo number_format($totalDenda, 0, ',', '.'); ?></div>
            <div class="report-summary-label">Total Denda</div>
        </div>
    </div>

    <!-- Tabel transaksi -->
    <table class="table report-table">
        <thead>
            <tr>
                <th>No</th>
                <th>Kode</th>
                <th>Peminjam</th>
                <th>Judul Buku</th>
                <th>Jumlah</th>
                <th>Tgl Pinjam</th>
                <th>Batas Kembali</th>
                <th>Dikembalikan</th>
                <th>Status</th>
                <th>Denda</th>
                <th>Kondisi Sebelum</th>
                <th>Kondisi Sesudah</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $kondisiBadgeColor = ['Baik' => 'green', 'Rusak Ringan' => 'orange', 'Rusak Berat' => 'red', 'Hilang' => 'gray'];
            $no = 1; foreach ($rows as $row): ?>
            <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo htmlspecialchars($row['kode_transaksi']); ?></td>
                <td><?php echo htmlspecialchars($row['nama_lengkap']); ?></td>
                <td><?php echo htmlspecialchars($row['judul']); ?></td>
                <td><?php echo (int) $row['jumlah']; ?></td>
                <td><?php echo htmlspecialchars($row['tanggal_pinjam']); ?></td>
                <td><?php echo htmlspecialchars($row['tanggal_kembali']); ?></td>
                <td><?php echo htmlspecialchars($row['tanggal_dikembalikan'] ?: '-'); ?></td>
                <td>
                    <span class="badge badge-<?php echo $statusBadgeColor[$row['status']]; ?> report-badge-print">
                        <?php echo $statusLabel[$row['status']]; ?>
                    </span>
                </td>
                <td><?php echo $row['denda'] > 0 ? 'Rp ' . number_format($row['denda'], 0, ',', '.') : '-'; ?></td>
                <td>
                    <?php if (!empty($row['kondisi_sebelum'])): ?>
                    <span class="badge badge-<?php echo $kondisiBadgeColor[$row['kondisi_sebelum']] ?? 'gray'; ?> report-badge-print"><?php echo htmlspecialchars($row['kondisi_sebelum']); ?></span>
                    <?php else: ?>-<?php endif; ?>
                </td>
                <td>
                    <?php if (!empty($row['kondisi_sesudah'])): ?>
                    <span class="badge badge-<?php echo $kondisiBadgeColor[$row['kondisi_sesudah']] ?? 'gray'; ?> report-badge-print"><?php echo htmlspecialchars($row['kondisi_sesudah']); ?></span>
                    <?php else: ?>-<?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php if ($totalRows === 0): ?>
            <tr><td colspan="12" class="text-center">Tidak ada data transaksi pada periode ini.</td></tr>
            <?php endif; ?>
        </tbody>
        <?php if ($totalRows > 0): ?>
        <tfoot>
            <tr>
                <td colspan="9" class="text-right"><strong>Total Denda</strong></td>
                <td><strong>Rp <?php echo number_format($totalDenda, 0, ',', '.'); ?></strong></td>
                <td colspan="2"></td>
            </tr>
        </tfoot>
        <?php endif; ?>
    </table>

    <!-- Footer laporan -->
    <div class="report-footer">
        <p class="report-print-meta">
            Dicetak oleh: <?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?>
            (<?php echo strtoupper($_SESSION['role']); ?>) &middot; <?php echo date('d F Y, H:i'); ?> WIB
        </p>
        <div class="report-signature-grid">
            <div class="report-signature-box">
                <p>Mengetahui,<br>Kepala Sekolah</p>
                <div class="report-signature-space"></div>
                <p class="report-signature-name">( _________________________ )</p>
            </div>
            <div class="report-signature-box">
                <p><?php echo htmlspecialchars(date('d F Y')); ?><br>Petugas Perpustakaan</p>
                <div class="report-signature-space"></div>
                <p class="report-signature-name">( <?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?> )</p>
            </div>
        </div>
    </div>

</div>
</body>
</html>
